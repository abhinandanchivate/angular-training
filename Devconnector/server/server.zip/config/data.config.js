const jwtSecret = "jwtSecret";

module.exports = jwtSecret;
