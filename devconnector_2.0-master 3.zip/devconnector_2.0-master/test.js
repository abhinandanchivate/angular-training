let personData = { name: 'abhi', age: 33 };
let counter = 0;
let res = personData.lenght;
console.log(res);
// for (let i of personData) {
//   console.log(i.key);
//   counter += 1;
// }

console.log(counter);

let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9];

// repeated elements to be removed
let set = new Set();
let final = [];

for (let i of arr) {
  set.add(i);
}
let arr2 = set.toArray();

console.log(arr2);
